# 安装命令

  `
  pip install MuskTest
  `
    
# 文档建设中...