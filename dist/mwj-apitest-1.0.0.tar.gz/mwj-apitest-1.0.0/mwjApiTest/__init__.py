# -*- coding: utf-8 -*-
'''
@Time : 2023/5/31 16:45
@Email : Lvan826199@163.com
@公众号 : 梦无矶的测试开发之路
@File : __init__.py.py
'''
__author__ = "梦无矶小仔"

from .manage import run